from .lab3 import dVdig, dRdig, dCdig, dVosc, drapp, dprod, dpoli, dlog, dlog10, curve_fitdx, ns_tex, ne_tex
from .WIP import chi2_pval