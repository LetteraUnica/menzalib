from .lab3 import dVdig, dRdig, dCdig, dVosc, dtosc, drapp, dprod, dpoli, dlog, dlog10
from .lab3 import curve_fitdx, ns_tex, ne_tex, chi2_pval, int_rette, stampa_matrice_latex