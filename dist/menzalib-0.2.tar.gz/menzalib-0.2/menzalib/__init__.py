from .lab3 import dVdig, dRdig, dCdig, dVosc, drapp, dprod, dpoli, dlog, dlog10
