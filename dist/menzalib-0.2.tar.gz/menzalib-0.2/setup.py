import setuptools

with open("README.md", "r") as fh:
    long_description = fh.read()

setuptools.setup(
      name="menzalib",
      version="0.2",
      author="Lettera",
      author_email="",
      description="Funzioni utili per lab3",
      url="",
      packages=setuptools.find_packages(),
      )
