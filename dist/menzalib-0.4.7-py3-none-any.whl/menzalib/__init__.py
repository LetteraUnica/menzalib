from .lab3 import dVdig, dRdig, dCdig, dVosc, drapp, dprod, dpoli, dlog, dlog10, curve_fitdx, ns_tex, ne_tex, stampa_matrice_latex, int_rette, chi2_pval, dt_osc
